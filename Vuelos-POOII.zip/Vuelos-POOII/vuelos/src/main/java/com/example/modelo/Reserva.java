package com.example.modelo;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

/**
 * Clase que representa una reserva de vuelo.
 * Una reserva tiene un identificador único, fecha de reserva, una lista de asientos, un vuelo y un cliente asociado.
 */
public class Reserva {

    private String idReserva = String.valueOf(UUID.randomUUID()); // Identificador único de la reserva
    private LocalDate fechaReserva; // Fecha en la que se realiza la reserva
    private List<Asiento> asientos; // Lista de asientos reservados
    private Vuelo vuelo; // Vuelo relacionado con la reserva
    private Cliente cliente; // Cliente que realiza la reserva

    /**
     * Constructor protegido por defecto.
     * Se utiliza para la creación de instancias dentro del paquete o en subclases.
     */
    protected Reserva() {}

    /**
     * Constructor que inicializa una reserva con la fecha, lista de asientos, vuelo y cliente.
     *
     * @param fechaReserva la fecha de la reserva
     * @param asientos la lista de asientos reservados
     * @param vuelo el vuelo relacionado con la reserva
     * @param cliente el cliente que realiza la reserva
     * @throws IllegalArgumentException si la fecha, la lista de asientos, el vuelo o el cliente son nulos o inválidos
     */
    public Reserva(LocalDate fechaReserva, List<Asiento> asientos, Vuelo vuelo, Cliente cliente) {
        if (fechaReserva == null) {
            throw new IllegalArgumentException("La FECHA no debe ser nula");
        }
        if (asientos == null || asientos.isEmpty()) {
            throw new IllegalArgumentException("La LISTA DE ASIENTOS no debe ser nula o vacía");
        }
        if (vuelo == null || cliente == null) {
            throw new IllegalArgumentException("El VUELO y/o el CLIENTE no deben estar vacíos o ser nulos");
        }

        this.fechaReserva = fechaReserva;
        this.asientos = asientos;
        this.vuelo = vuelo;
        this.cliente = cliente;
    }

    /**
     * Obtiene el identificador de la reserva.
     *
     * @return el identificador único de la reserva
     */
    public String getIdReserva() {
        return idReserva; // Retorna el ID de la reserva
    }

    /**
     * Obtiene la fecha de la reserva.
     *
     * @return la fecha en la que se realizó la reserva
     */
    public LocalDate getFechaReserva() {
        return fechaReserva; // Retorna la fecha de la reserva
    }

    /**
     * Obtiene la lista de asientos reservados.
     *
     * @return la lista de asientos
     */
    public List<Asiento> getAsientos() {
        return asientos; // Retorna la lista de asientos reservados
    }

    /**
     * Obtiene el vuelo relacionado con la reserva.
     *
     * @return el vuelo de la reserva
     */
    public Vuelo getVuelo() {
        return vuelo; // Retorna el vuelo relacionado con la reserva
    }

    /**
     * Obtiene el cliente que realizó la reserva.
     *
     * @return el cliente que realizó la reserva
     */
    public Cliente getCliente() {
        return cliente; // Retorna el cliente que realizó la reserva
    }
}

