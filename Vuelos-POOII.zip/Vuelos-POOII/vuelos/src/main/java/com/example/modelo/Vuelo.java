package com.example.modelo;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Clase que representa un vuelo en el sistema de reservación.
 * Un vuelo tiene un identificador único, fechas de salida y llegada, un destino y un avión asignado.
 */
public class Vuelo {

    private String idVuelo = String.valueOf(UUID.randomUUID()); // Identificador único del vuelo
    private LocalDateTime salida; // Fecha y hora de salida del vuelo
    private LocalDateTime llegada; // Fecha y hora de llegada del vuelo
    private Aeropuerto destino; // Aeropuerto de destino del vuelo
    private Avion avion; // Avión asignado al vuelo

    /**
     * Constructor protegido por defecto.
     * Se utiliza para la creación de instancias dentro del paquete o en subclases.
     */
    protected Vuelo() {}

    /**
     * Constructor que inicializa un vuelo con la fecha y hora de salida, llegada, destino y avión.
     *
     * @param salida la fecha y hora de salida del vuelo
     * @param llegada la fecha y hora de llegada del vuelo
     * @param destino el aeropuerto de destino del vuelo
     * @param avion el avión asignado al vuelo
     * @throws IllegalArgumentException si las fechas, el destino o el avión son nulos
     */
    public Vuelo(LocalDateTime salida, LocalDateTime llegada, Aeropuerto destino, Avion avion) {
        if (salida == null || llegada == null) {
            throw new IllegalArgumentException("Las FECHAS no deben ser nulas");
        }
        if (destino == null || avion == null) {
            throw new IllegalArgumentException("El AVION y/o el DESTINO no deben ser nulos");
        }

        this.salida = salida;
        this.llegada = llegada;
        this.destino = destino;
        this.avion = avion;
    }

    /**
     * Obtiene el identificador del vuelo.
     *
     * @return el identificador único del vuelo
     */
    public String getIdVuelo() {
        return idVuelo; // Retorna el ID del vuelo
    }

    /**
     * Obtiene la fecha y hora de salida del vuelo.
     *
     * @return la fecha y hora de salida
     */
    public LocalDateTime getSalida() {
        return salida; // Retorna la fecha y hora de salida del vuelo
    }

    /**
     * Obtiene la fecha y hora de llegada del vuelo.
     *
     * @return la fecha y hora de llegada
     */
    public LocalDateTime getLlegada() {
        return llegada; // Retorna la fecha y hora de llegada del vuelo
    }

    /**
     * Obtiene el aeropuerto de destino del vuelo.
     *
     * @return el aeropuerto de destino
     */
    public Aeropuerto getDestino() {
        return destino; // Retorna el aeropuerto de destino del vuelo
    }

    /**
     * Obtiene el avión asignado al vuelo.
     *
     * @return el avión del vuelo
     */
    public Avion getAvion() {
        return avion; // Retorna el avión asignado al vuelo
    }

    /**
     * Establece un nuevo avión para el vuelo.
     *
     * @param avion el nuevo avión a asignar
     * @throws IllegalArgumentException si el avión es nulo
     */
    public void setAvion(Avion avion) {
        if (avion == null) {
            throw new IllegalArgumentException("El AVION no debe estar vacío o ser nulo");
        }
        this.avion = avion; // Asigna el nuevo avión al vuelo
    }
}
