package com.example.modelo;

import java.util.UUID;

/**
 * La clase Aeropuerto representa un aeropuerto con un identificador único, un nombre y una ciudad.
 */
public class Aeropuerto {

    /**
     * Identificador único del aeropuerto, generado automáticamente al instanciar la clase.
     */
    private String idAeropuerto = String.valueOf(UUID.randomUUID());

    /**
     * Nombre del aeropuerto.
     */
    private String nombre;

    /**
     * Ciudad en la que se encuentra el aeropuerto.
     */
    private String ciudad;

    /**
     * Constructor protegido sin parámetros.
     * Está diseñado para ser utilizado solo por clases derivadas.
     */
    protected Aeropuerto() {
    }

    /**
     * Crea una nueva instancia de Aeropuerto con el nombre y la ciudad especificados.
     * 
     * @param nombre El nombre del aeropuerto.
     * @param ciudad La ciudad en la que se encuentra el aeropuerto.
     * @throws IllegalArgumentException si el nombre o la ciudad son nulos o están vacíos.
     */
    public Aeropuerto(String nombre, String ciudad) {
        if (nombre.trim().isEmpty() || nombre == null || ciudad.trim().isEmpty() || ciudad == null) {
            throw new IllegalArgumentException("El NOMBRE y/o la CIUDAD no deben estar vacías o ser nulas");
        }
        this.nombre = nombre;
        this.ciudad = ciudad;
    }

    /**
     * Devuelve el identificador único del aeropuerto.
     * 
     * @return El identificador único del aeropuerto (UUID).
     */
    public String getIdAeropuerto() {
        String retIdAeropuerto = idAeropuerto;
        return retIdAeropuerto;
    }

    /**
     * Devuelve el nombre del aeropuerto.
     * 
     * @return El nombre del aeropuerto.
     */
    public String getNombre() {
        String retNombre = nombre;
        return retNombre;
    }

    /**
     * Devuelve la ciudad en la que se encuentra el aeropuerto.
     * 
     * @return La ciudad del aeropuerto.
     */
    public String getCiudad() {
        String retCiudad = ciudad;
        return retCiudad;
    }

    /**
     * Establece un nuevo nombre para el aeropuerto.
     * 
     * @param nuevoNombre El nuevo nombre del aeropuerto.
     * @throws IllegalArgumentException si el nuevo nombre es nulo o está vacío.
     */
    public void setNombre(String nuevoNombre) {
        if (nuevoNombre.trim().isEmpty() || nuevoNombre == null) {
            throw new IllegalArgumentException("El NOMBRE no debe estar vacío o ser nulo");
        }
        this.nombre = nuevoNombre;
    }
}
