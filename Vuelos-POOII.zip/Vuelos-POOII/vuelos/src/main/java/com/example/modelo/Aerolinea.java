package com.example.modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * La clase Aerolinea representa una aerolínea que gestiona aviones.
 * Cada aerolínea tiene un nombre, un identificador único (UUID), y una lista de aviones activos.
 */
public class Aerolinea {

    /**
     * Identificador único de la aerolínea, generado automáticamente al instanciar la clase.
     */
    private String idAerolinea = String.valueOf(UUID.randomUUID());

    /**
     * Nombre de la aerolínea.
     */
    private String nombre;

    /**
     * Lista de aviones activos que pertenecen a la aerolínea.
     */
    private List<Avion> avionesActivos = new ArrayList<>();

    /**
     * Constructor protegido sin parámetros.
     * Está diseñado para ser utilizado solo por clases derivadas.
     */
    protected Aerolinea() {
    }

    /**
     * Crea una nueva instancia de Aerolinea con un nombre especificado.
     * 
     * @param nombre El nombre de la aerolínea.
     * @throws IllegalArgumentException si el nombre es nulo o está vacío.
     */
    public Aerolinea(String nombre) {
        if (nombre.trim().isEmpty() || nombre == null) {
            throw new IllegalArgumentException("El NOMBRE no debe estar vacío o ser nulo");
        }
        this.nombre = nombre;
    }

    /**
     * Devuelve el identificador único de la aerolínea.
     * 
     * @return El identificador único de la aerolínea (UUID).
     */
    public String getIdAerolinea() {
        String retIdAerolinea = idAerolinea;
        return retIdAerolinea;
    }

    /**
     * Devuelve el nombre de la aerolínea.
     * 
     * @return El nombre de la aerolínea.
     */
    public String getNombre() {
        String retNombre = nombre;
        return retNombre;
    }

    /**
     * Devuelve la lista de aviones activos de la aerolínea.
     * 
     * @return Una lista de los aviones activos.
     */
    public List<Avion> getAvionesActivos() {
        List<Avion> retAvionesActivos = avionesActivos;
        return retAvionesActivos;
    }

    /**
     * Establece un nuevo nombre para la aerolínea.
     * 
     * @param nuevoNombre El nuevo nombre de la aerolínea.
     * @throws IllegalArgumentException si el nuevo nombre es nulo o está vacío.
     */
    public void setNombre(String nuevoNombre) {
        if (nuevoNombre.trim().isEmpty() || nuevoNombre == null) {
            throw new IllegalArgumentException("El NOMBRE no debe estar vacío o ser nulo");
        }
        this.nombre = nuevoNombre;
    }

    /**
     * Añade un nuevo avión a la lista de aviones activos de la aerolínea.
     * 
     * @param nuevoAvion El avión que se agregará.
     * @throws IllegalArgumentException si el avión es nulo.
     */
    public void setAvionActivo(Avion nuevoAvion) {
        if (nuevoAvion == null) {
            throw new IllegalArgumentException("El AVION no debe ser nulo");
        }
        this.avionesActivos.add(nuevoAvion);
    }

    /**
     * Elimina un avión de la lista de aviones activos de la aerolínea.
     * 
     * @param avionRetirado El avión que se eliminará de la lista de aviones activos.
     * @throws IllegalArgumentException si el avión es nulo.
     */
    public void removerAvionActivo(Avion avionRetirado) {
        if (avionRetirado == null) {
            throw new IllegalArgumentException("El AVION no debe ser nulo");
        }
        this.avionesActivos.remove(avionRetirado);
    }
}
