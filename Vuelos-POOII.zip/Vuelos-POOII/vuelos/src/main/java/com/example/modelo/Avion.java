package com.example.modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * La clase Avion representa un avión dentro del sistema de reservaciones de vuelos.
 * Cada avión tiene un identificador único, un modelo, una cantidad de asientos y está asociado a una aerolínea.
 */
public class Avion {

    /**
     * Identificador único del avión, generado automáticamente al instanciar la clase.
     */
    private String idAvion = String.valueOf(UUID.randomUUID());

    /**
     * Modelo del avión.
     */
    private String modelo;

    /**
     * Cantidad de asientos en el avión.
     */
    private int cantidadAsientos;

    /**
     * Lista que almacena los asientos del avión.
     */
    private List<Asiento> asientos;

    /**
     * Aerolínea a la que pertenece el avión.
     */
    private Aerolinea aerolinea;

    /**
     * Constructor que crea un avión con el modelo y la cantidad de asientos especificados.
     * 
     * @param modelo El modelo del avión.
     * @param cantidadAsientos La cantidad de asientos en el avión.
     * @throws IllegalArgumentException si el modelo está vacío o es nulo, o si la cantidad de asientos es menor o igual a 0.
     */
    public Avion(String modelo, int cantidadAsientos) {
        if (modelo.trim().isEmpty() || modelo == null || cantidadAsientos <= 0) {
            throw new IllegalArgumentException("El MODELO y/o la CANTIDAD DE ASIENTOS no deben ser nulos");
        }

        this.modelo = modelo;
        this.cantidadAsientos = cantidadAsientos;
        this.asientos = new ArrayList<>();

        // Inicializa la lista de asientos, todos en estado "true" (ocupado).
        for (int i = 0; i < cantidadAsientos; i++) {
            asientos.add(new Asiento(true)); 
        }
    }

    /**
     * Devuelve el identificador único del avión.
     * 
     * @return El identificador único del avión (UUID).
     */
    public String getIdAvion() {
        String retIdAvion = idAvion;
        return retIdAvion;
    }

    /**
     * Devuelve el modelo del avión.
     * 
     * @return El modelo del avión.
     */
    public String getModelo() {
        String retModelo = modelo;
        return retModelo;    
    }

    /**
     * Devuelve la cantidad de asientos en el avión.
     * 
     * @return La cantidad de asientos del avión.
     */
    public int getCantidadAsientos() {
        int retCantidadAsientos = cantidadAsientos;
        return retCantidadAsientos;    
    }

    /**
     * Devuelve la lista de asientos del avión.
     * 
     * @return Una lista de objetos {@link Asiento} representando los asientos del avión.
     */
    public List<Asiento> getAsientos() {
        List<Asiento> retAsientos = asientos;
        return retAsientos;
    }

    /**
     * Devuelve la aerolínea a la que pertenece el avión.
     * 
     * @return La aerolínea asociada al avión.
     */
    public Aerolinea getAerolinea() {
        Aerolinea retAerolinea = aerolinea;
        return retAerolinea;    
    }

    /**
     * Establece la aerolínea a la que pertenece el avión.
     * 
     * @param aerolinea La nueva aerolínea asociada al avión.
     * @throws IllegalArgumentException si la aerolínea es nula.
     */
    public void setAerolinea(Aerolinea aerolinea) {
        if (aerolinea == null) {
            throw new IllegalArgumentException("La AEROLINEA no debe estar vacía o ser nula");
        }
        this.aerolinea = aerolinea;    
    }
}
