package com.example.modelo;

/**
 * Clase que representa un cliente en el sistema de reservación de vuelos.
 * Un cliente tiene un DNI y un nombre completo.
 */
public class Cliente {

    private String dni; // Documento Nacional de Identidad del cliente
    private String nombreCompleto; // Nombre completo del cliente

    /**
     * Constructor protegido por defecto.
     * Se utiliza para la creación de instancias dentro del paquete o en subclases.
     */
    protected Cliente() {}

    /**
     * Constructor que inicializa un cliente con el DNI y el nombre completo.
     *
     * @param dni el Documento Nacional de Identidad del cliente
     * @param nombre el nombre completo del cliente
     * @throws IllegalArgumentException si el DNI o el nombre completo son nulos o están vacíos
     */
    public Cliente(String dni, String nombre) {
        if (dni.trim().isEmpty() || dni == null || nombre.trim().isEmpty() || nombre == null) {
            throw new IllegalArgumentException("El DNI y/o el NOMBRE COMPLETO no deben estar vacíos o ser nulos");
        }
        this.dni = dni;
        this.nombreCompleto = nombre;
    }

    /**
     * Obtiene el DNI del cliente.
     *
     * @return el Documento Nacional de Identidad del cliente
     */
    public String getDni() {
        return dni; // Retorna el DNI del cliente
    }

    /**
     * Obtiene el nombre completo del cliente.
     *
     * @return el nombre completo del cliente
     */
    public String getNombreCompleto() {
        return nombreCompleto; // Retorna el nombre completo del cliente
    }

    /**
     * Establece un nuevo nombre completo para el cliente.
     *
     * @param nuevoNombre el nuevo nombre completo del cliente
     * @throws IllegalArgumentException si el nuevo nombre está vacío o es nulo
     */
    public void setNombreCompleto(String nuevoNombre) {
        if (nuevoNombre.trim().isEmpty() || nuevoNombre == null) {
            throw new IllegalArgumentException("El NOMBRE COMPLETO no debe estar vacío o ser nulo");
        }
        this.nombreCompleto = nuevoNombre; // Asigna el nuevo nombre completo al cliente
    }
}
