package com.example.modelo;

import java.util.UUID;

/**
 * La clase Asiento representa un asiento en un avión, que tiene un identificador único y un estado que indica si está ocupado o disponible.
 */
public class Asiento {

    /**
     * Identificador único del asiento, generado automáticamente al instanciar la clase.
     */
    private String idAsiento = String.valueOf(UUID.randomUUID());

    /**
     * Estado del asiento. Puede ser true si está ocupado o false si está disponible.
     */
    private boolean estado;

    /**
     * Constructor protegido sin parámetros.
     * Está diseñado para ser utilizado solo por clases derivadas.
     */
    protected Asiento() {}

    /**
     * Crea una nueva instancia de Asiento con el estado especificado.
     * 
     * @param estado El estado inicial del asiento (true para ocupado, false para disponible).
     */
    public Asiento(boolean estado) {
        this.estado = estado;
    }

    /**
     * Devuelve el identificador único del asiento.
     * 
     * @return El identificador único del asiento (UUID).
     */
    public String getIdAsiento() {
        String retIdAsiento = idAsiento;
        return retIdAsiento;
    }

    /**
     * Devuelve el estado actual del asiento.
     * 
     * @return true si el asiento está ocupado, false si está disponible.
     */
    public boolean isEstado() {
        boolean retEstado = estado;
        return retEstado;
    }

    /**
     * Establece un nuevo estado para el asiento.
     * 
     * @param estado El nuevo estado del asiento (true para ocupado, false para disponible).
     */
    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}

