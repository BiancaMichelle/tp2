package com.example;

/**
 * Clase principal de la aplicación.
 * Esta clase contiene el método main que se utiliza como punto de entrada de la aplicación.
 */
public class App 
{
    /**
     * Método principal que inicia la aplicación.
     * Este método imprime "Hello World!" en la consola.
     *
     * @param args argumentos de línea de comando (no utilizados en esta aplicación)
     */
    public static void main(String[] args)
    {
        System.out.println("Hello World!"); // Imprime el mensaje "Hello World!" en la consola
    }
}
