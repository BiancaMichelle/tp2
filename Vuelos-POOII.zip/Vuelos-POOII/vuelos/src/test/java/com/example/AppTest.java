package com.example;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Clase de prueba para la aplicación.
 * Esta clase contiene pruebas unitarias para validar la funcionalidad de la aplicación.
 */
public class AppTest 
{
    /**
     * Prueba básica que siempre retorna verdadero.
     * Esta prueba se utiliza como un ejemplo para comprobar que el entorno de pruebas está funcionando correctamente.
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue(true); // Verifica que la expresión true sea verdadera
    }
}
